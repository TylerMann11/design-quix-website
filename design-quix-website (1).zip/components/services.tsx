import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Palette, Smartphone, Search, Zap } from "lucide-react"

const services = [
  {
    icon: Palette,
    title: "Custom Web Design",
    description: "Beautiful, professional websites tailored to your brand and industry",
  },
  {
    icon: Smartphone,
    title: "Mobile Optimization",
    description: "Fully responsive designs that look perfect on all devices",
  },
  {
    icon: Search,
    title: "SEO Integration",
    description: "Built-in SEO to help customers find you on Google",
  },
  {
    icon: Zap,
    title: "Lead Generation",
    description: "Contact forms and call-to-actions that convert visitors to customers",
  },
]

export default function Services() {
  return (
    <section id="services" className="py-16 px-4 bg-white">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">What We Provide</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Everything your business needs to establish a strong online presence and attract more customers
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => (
            <Card key={index} className="border-2 hover:border-blue-200 transition-colors text-center">
              <CardHeader>
                <service.icon className="h-10 w-10 text-blue-600 mx-auto mb-3" />
                <CardTitle className="text-lg">{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600">{service.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
