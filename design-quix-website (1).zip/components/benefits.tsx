import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, Users, Phone } from "lucide-react"

const benefits = [
  {
    icon: TrendingUp,
    title: "Increase Revenue by 40%",
    description:
      "Professional websites convert 40% more visitors into paying customers compared to outdated or missing websites.",
    stat: "40% More Sales",
  },
  {
    icon: Users,
    title: "Build Customer Trust",
    description:
      "75% of consumers judge a company's credibility based on their website design. Don't lose customers to competitors.",
    stat: "75% Trust Factor",
  },
  {
    icon: Phone,
    title: "Generate More Leads",
    description:
      "Strategic contact forms and call-to-actions turn website visitors into qualified leads for your business.",
    stat: "3x More Leads",
  },
]

export default function Benefits() {
  return (
    <section className="py-16 px-4 bg-white">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">How a Professional Website Grows Your Business</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Don't let a poor or missing website cost you customers. Here's the real impact of the right website.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {benefits.map((benefit, index) => (
            <Card key={index} className="border-2 hover:border-blue-200 transition-colors text-center">
              <CardHeader>
                <div className="bg-blue-100 p-3 rounded-lg w-fit mx-auto mb-4">
                  <benefit.icon className="h-8 w-8 text-blue-600" />
                </div>
                <CardTitle className="text-lg text-gray-900">{benefit.title}</CardTitle>
                <div className="text-2xl font-bold text-blue-600">{benefit.stat}</div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-sm leading-relaxed">{benefit.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="bg-red-50 rounded-2xl p-8 text-center border-2 border-red-200">
          <h3 className="text-xl font-bold text-gray-900 mb-6">The Cost of NOT Having a Professional Website</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-red-600 mb-2">68%</div>
              <p className="text-gray-700 text-sm">of customers won't call a business without a website</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-red-600 mb-2">$2,400</div>
              <p className="text-gray-700 text-sm">average monthly revenue lost per business</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-red-600 mb-2">85%</div>
              <p className="text-gray-700 text-sm">choose competitors with better websites</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
