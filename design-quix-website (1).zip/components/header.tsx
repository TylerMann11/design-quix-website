"use client"

import { Button } from "@/components/ui/button"
import { Phone } from "lucide-react"
import { useState } from "react"

const navItems = [
  { name: "Home", href: "#home" },
  { name: "Services", href: "#services" },
  { name: "Testimonials", href: "#testimonials" },
  { name: "Free Quote", href: "#contact" },
]

export default function Header() {
  const [activeSection, setActiveSection] = useState("home")

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
      setActiveSection(href.replace("#", ""))
    }
  }

  return (
    <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-gray-200 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-blue-600">Design Quix</h1>
          </div>

          <nav className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.name}
                onClick={() => scrollToSection(item.href)}
                className={`text-sm font-medium transition-colors hover:text-blue-600 ${
                  activeSection === item.href.replace("#", "")
                    ? "text-blue-600 border-b-2 border-blue-600 pb-1"
                    : "text-gray-700"
                }`}
              >
                {item.name}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2 text-sm text-gray-600">
              <Phone className="h-4 w-4" />
              <span>(778) 231-1238</span>
            </div>
            <Button size="sm" onClick={() => scrollToSection("#contact")}>
              Get Quote
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}
