"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Star, ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { useState } from "react"

const testimonials = [
  {
    name: "Surinder D.",
    business: "Local Landscaping Company",
    location: "Vancouver, BC",
    image: "/placeholder.svg?height=80&width=80",
    rating: 5,
    text: "Our business completely transformed after getting our new website. We went from getting 2-3 calls per week to 15-20 calls per week. The website looks incredibly professional and our customers constantly compliment it. Best investment we've made for our company.",
  },
  {
    name: "Sarah C.",
    business: "HVAC Service Company",
    location: "Surrey, BC",
    image: "/placeholder.svg?height=80&width=80",
    rating: 5,
    text: "I was skeptical about needing a website, but after working with Design Quix, our emergency service calls increased by 60%. The online booking system saves us so much time, and customers love being able to schedule maintenance online.",
  },
  {
    name: "David T.",
    business: "Moving Services",
    location: "Richmond, BC",
    image: "/placeholder.svg?height=80&width=80",
    rating: 5,
    text: "The quote calculator on our new website has been a game-changer. Customers can get instant estimates, and we've seen a 45% increase in bookings. The team really understood our business needs and delivered exactly what we wanted.",
  },
]

export default function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length)
  }

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length)
  }

  return (
    <section id="testimonials" className="py-16 px-4 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">What Our Clients Say</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Real results from real business owners who transformed their companies with professional websites
          </p>
        </div>

        <div className="relative">
          <div className="overflow-hidden rounded-lg">
            <div
              className="flex transition-transform duration-300 ease-in-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {testimonials.map((testimonial, index) => (
                <div key={index} className="w-full flex-shrink-0">
                  <Card className="mx-4 hover:shadow-lg transition-shadow max-w-2xl mx-auto">
                    <CardContent className="p-8 text-center">
                      <div className="flex items-center justify-center gap-1 mb-6">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                      <p className="text-gray-700 mb-8 leading-relaxed text-lg italic">"{testimonial.text}"</p>
                      <div className="flex items-center justify-center gap-4">
                        <Image
                          src={testimonial.image || "/placeholder.svg"}
                          alt={testimonial.name}
                          width={60}
                          height={60}
                          className="rounded-full"
                        />
                        <div className="text-left">
                          <div className="font-semibold text-gray-900 text-lg">{testimonial.name}</div>
                          <div className="text-gray-600">{testimonial.business}</div>
                          <div className="text-sm text-gray-500">{testimonial.location}</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>

          {testimonials.length > 1 && (
            <>
              <Button
                variant="outline"
                size="icon"
                className="absolute left-0 top-1/2 -translate-y-1/2 bg-white shadow-lg"
                onClick={prevSlide}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="absolute right-0 top-1/2 -translate-y-1/2 bg-white shadow-lg"
                onClick={nextSlide}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </>
          )}

          <div className="flex justify-center mt-8 gap-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentIndex ? "bg-blue-600" : "bg-gray-300"
                }`}
                onClick={() => setCurrentIndex(index)}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
