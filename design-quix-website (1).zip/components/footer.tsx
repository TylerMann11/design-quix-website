import { Phone, Mail } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center">
          <h3 className="text-2xl font-bold mb-4">Design Quix</h3>
          <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
            Professional websites for service-based businesses. We help landscaping, HVAC, moving, and other local
            companies grow their business online.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <div className="flex items-center gap-2">
              <Phone className="h-5 w-5" />
              <span>(778) 231-1238</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="h-5 w-5" />
              <span>designquix@gmail.com</span>
            </div>
          </div>

          <div className="border-t border-gray-700 pt-8">
            <p className="text-gray-400 text-sm">
              © 2024 Design Quix. All rights reserved. | Professional Website Design for Service-Based Businesses
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
