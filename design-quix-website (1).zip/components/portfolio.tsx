"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"
import Image from "next/image"
import { useState } from "react"

const portfolioItems = [
  {
    title: "Professional Landscaping Website",
    category: "Landscaping",
    description: "Modern design with service showcase, online booking, and customer gallery",
    image:
      "/placeholder.svg?height=400&width=600&text=GreenScape+Landscaping+Website+Hero+Section+with+Beautiful+Garden+Background+Call+Now+Button+Services+Gallery",
    features: ["Online Booking", "Service Gallery", "Customer Reviews", "Quote Calculator"],
  },
  {
    title: "HVAC Service Website",
    category: "HVAC",
    description: "Professional site with emergency callouts, maintenance scheduling, and service areas",
    image:
      "/placeholder.svg?height=400&width=600&text=CoolAir+HVAC+Professional+Website+24/7+Emergency+Service+Call+Button+Service+Areas+Map",
    features: ["24/7 Emergency Form", "Service Areas Map", "Maintenance Plans", "Live Chat"],
  },
]

export default function Portfolio() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % portfolioItems.length)
  }

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + portfolioItems.length) % portfolioItems.length)
  }

  return (
    <section id="portfolio" className="py-16 px-4 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Website Examples for Your Industry</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            See how we create professional websites that drive results for businesses like yours
          </p>
        </div>

        <div className="relative">
          <div className="overflow-hidden rounded-lg">
            <div
              className="flex transition-transform duration-300 ease-in-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {portfolioItems.map((item, index) => (
                <div key={index} className="w-full flex-shrink-0">
                  <Card className="mx-4 overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="relative h-80">
                      <Image src={item.image || "/placeholder.svg"} alt={item.title} fill className="object-cover" />
                      <div className="absolute top-4 left-4">
                        <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                          {item.category}
                        </span>
                      </div>
                    </div>
                    <CardContent className="p-6">
                      <h3 className="text-xl font-bold text-gray-900 mb-2">{item.title}</h3>
                      <p className="text-gray-600 mb-4">{item.description}</p>
                      <div className="flex flex-wrap gap-2">
                        {item.features.map((feature, featureIndex) => (
                          <span key={featureIndex} className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">
                            {feature}
                          </span>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ))}
            </div>
          </div>

          {portfolioItems.length > 1 && (
            <>
              <Button
                variant="outline"
                size="icon"
                className="absolute left-0 top-1/2 -translate-y-1/2 bg-white shadow-lg"
                onClick={prevSlide}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="absolute right-0 top-1/2 -translate-y-1/2 bg-white shadow-lg"
                onClick={nextSlide}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </>
          )}

          <div className="flex justify-center mt-6 gap-2">
            {portfolioItems.map((_, index) => (
              <button
                key={index}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentIndex ? "bg-blue-600" : "bg-gray-300"
                }`}
                onClick={() => setCurrentIndex(index)}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
