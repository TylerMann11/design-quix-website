"use server"

export async function submitContactForm(prevState: any, formData: FormData) {
  try {
    const name = formData.get("name") as string
    const phone = formData.get("phone") as string
    const email = formData.get("email") as string
    const business = formData.get("business") as string
    const industry = formData.get("industry") as string
    const message = formData.get("message") as string

    // Validate required fields
    if (!name || !phone || !email) {
      return {
        success: false,
        error: "Please fill in all required fields.",
      }
    }

    // Check if we have the API key (for production)
    if (process.env.RESEND_API_KEY) {
      // Only import and use Resend if API key is available
      const { Resend } = await import("resend")
      const resend = new Resend(process.env.RESEND_API_KEY)

      // Send email using Resend
      await resend.emails.send({
        from: "Design Quix <onboarding@resend.dev>", // Using Resend's shared domain for now
        to: ["designquix@gmail.com"],
        subject: `New Website Quote Request from ${name}`,
        html: `
          <h2>New Website Quote Request</h2>
          <p><strong>Name:</strong> ${name}</p>
          <p><strong>Phone:</strong> ${phone}</p>
          <p><strong>Email:</strong> ${email}</p>
          <p><strong>Business:</strong> ${business || "Not provided"}</p>
          <p><strong>Industry:</strong> ${industry || "Not provided"}</p>
          <p><strong>Message:</strong></p>
          <p>${message || "No message provided"}</p>
          <hr>
          <p><em>Submitted at: ${new Date().toLocaleString()}</em></p>
        `,
      })
    } else {
      // For preview/development - just log the data
      console.log("New lead received (Preview Mode):", {
        name,
        phone,
        email,
        business,
        industry,
        message,
        timestamp: new Date().toISOString(),
      })
    }

    return {
      success: true,
      message: "Thank you! We will contact you within 24 hours.",
    }
  } catch (error) {
    console.error("Form submission error:", error)
    return {
      success: false,
      error: "Something went wrong. Please try again or call us directly at (778) 231-1238.",
    }
  }
}
